﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace routeForSightseeing
{
    internal class Program
    {
		//Класс Достопримечательности
		public class Attraction
		{
			public string Name { get; set; }
			public float Time { get; set; }
			public int Importance { get; set; }

			public Attraction(string name, float time, int importance)
			{
				this.Name = name;
				this.Time = time;
				this.Importance = importance;
			}

			public void PrintInfo()
			{
				Console.WriteLine($"{Name}," +
                    $" Затраты по времени: {Time}, Важность: {Importance}");
			}
		}
		static void Main(string[] args)
		{
			//Количество доступных часов
			float countTime = 48 - 2 * 8, oneDay = countTime / 2, twoDay;
			twoDay = oneDay;

			Console.WriteLine($"Количество общего времени: {countTime} часа");
			Console.WriteLine($"Количество времени первого дня: {oneDay} часа");
			Console.WriteLine($"Количество времени второго дня: {twoDay} часа");

			//Заполнение листа исходными данными
			List<Attraction> attraction = new List<Attraction>()
			{
				new Attraction("Исаакиевский собор", 5, 10),
				new Attraction("Эрмитаж", 8, 11),
				new Attraction("Кунсткамера", 3.5f, 4),
				new Attraction("Петропавловская крепость", 10, 7),
				new Attraction("Ленинградский зоопарк", 9, 15),
				new Attraction("Медный всадник", 1, 17),
				new Attraction("Казанский собор", 4, 3),
				new Attraction("Спас на Крови", 2, 9),
				new Attraction("Зимний дворец Петра I", 7, 12),
				new Attraction("Зоологический музей", 5.5f, 6),
				new Attraction("Музей обороны и блокады Ленинграда", 3, 19),
				new Attraction("Русский музей", 5, 8),
				new Attraction("Навестить друзей", 12, 20),
				new Attraction("Музей восковых фигур", 2, 13),
				new Attraction("Литературно-мемориальный музей Ф.М. Достоевского", 4, 2),
				new Attraction("Екатерининский дворец", 1.5f, 5),
				new Attraction("Петербургский музей кукол", 1, 14),
				new Attraction("Музей микроминиатюры «Русский Левша»", 3, 18),
				new Attraction("Всероссийский музей А.С. Пушкина и филиалы", 6, 1),
				new Attraction("Музей современного искусства Эрарта", 7, 16)
			};

			
			var sortedList = attraction.OrderBy(x => x.Importance).ToList();
			List<Attraction> list = new List<Attraction>();

			Console.WriteLine("Достопримечательности: ");
			foreach (var attr in sortedList)
			{
				attr.PrintInfo();
			}

			//int countStep = 0;
			//Dictionary<int, Attraction> count = new Dictionary<int, Attraction>();

			//for (int i = 0; i < sortedList.Count; i++)
			//{
			//	for (int j = 0; j < sortedList.Count; j++)
			//	{
			//		if (oneDay - sortedList[j].Time > 0)
			//		{
			//			Console.WriteLine("Время: " + oneDay);
			//			Console.WriteLine("Достопримечательность: " + sortedList[j].Name);
			//			oneDay -= sortedList[j].Time;
			//			countStep++;
			//		}
			//		else
			//			continue;
			//	}
			//}

			

			//расчет времени для первого дня
			for (int i = 0; i < sortedList.Count; i++)
            {
				if (sortedList[i].Time.ToString().Length < 3 && oneDay - sortedList[i].Time >= 0)
				{
					Console.WriteLine("Достопримечательность: " + sortedList[i].Name);
					Console.WriteLine("Время первого дня: " + oneDay);
					oneDay -= sortedList[i].Time;
					list.Add(sortedList[i]);
				}
				else
					continue;
			}
			Console.WriteLine("Время первого дня: " + oneDay);
			Console.WriteLine();

			var sortedList2 = sortedList.Except(list).ToList();

			//расчет времени для второго дня
			for (int i = 0; i < sortedList2.Count; i++)
			{
				if (sortedList2[i].Time.ToString().Length <3 && twoDay - sortedList2[i].Time >= 0)
				{
					Console.WriteLine("Достопримечательность: " + sortedList2[i].Name);
					Console.WriteLine("Время второго дня: " + twoDay);
					twoDay -= sortedList2[i].Time;
				}
				else
					continue;
			}
			Console.WriteLine("Время второго дня: " + twoDay);

			Console.ReadKey();
		}
    }
}
